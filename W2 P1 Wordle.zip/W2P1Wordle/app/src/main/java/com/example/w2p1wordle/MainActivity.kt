package com.example.w2p1wordle

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fun main() {
            val word = "love" // the word to guess
            var guess: String // variable to hold user's guess
            var attempts = 0 // counter for number of attempts

            println("Guess the four-letter word:")

            do {
                print("Attempt ${attempts + 1}: ")
                guess = readLine()!!.toLowerCase()

                if (guess.length != 4) {
                    println("Your guess should be a four-letter word.")
                } else {
                    attempts++
                    val correctLetters = mutableListOf<Char>()
                    var correctPositions = 0

                    for (i in guess.indices) {
                        if (guess[i] == word[i]) {
                            correctPositions++
                        } else if (word.contains(guess[i])) {
                            correctLetters.add(guess[i])
                        }
                    }

                    if (correctPositions == 4) {
                        println("Congratulations, you guessed the word in $attempts attempts!")
                    } else {
                        println("Correct letters: ${correctLetters.distinct().joinToString(", ")}")
                        println("Correct positions: $correctPositions")
                    }
                }

            } while (guess != word)
        }

    }
}